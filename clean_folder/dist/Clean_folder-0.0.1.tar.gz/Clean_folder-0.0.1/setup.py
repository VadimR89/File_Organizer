from setuptools import setup, find_namespace_packages

setup(
    name='Clean_folder',
    version='0.0.1',
    description='Very useful code',
    url='https://github.com/VadimR89/File_Organizer',
    author='VadimR89',
    author_email='rabtsun.vadim@gmail.com',
    license='MIT',
    packages=['clean_folder'],
    install_requires=['os', 'shutil', 'sys', 're', 'collections', 'pathlib'],
)