from clean import main

__all__ = ['main']